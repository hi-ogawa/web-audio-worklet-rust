# misc

```sh
# downloaded from https://github.com/PolyMeilex/OxiSynth/blob/16875cee0dec96c7ba67db2d9263e2766ddc27b1/testdata/sin.sf2
wget https://github.com/PolyMeilex/OxiSynth/raw/master/testdata/sin.sf2

# archive
tar -cvzf sin.tar.gz sin.sf2 README.md
```
